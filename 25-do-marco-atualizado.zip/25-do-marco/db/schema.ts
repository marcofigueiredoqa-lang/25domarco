import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const settings=sqliteTable('settings',{key:text('key').primaryKey(),value:text('value').notNull()});
export const photos=sqliteTable('photos',{id:text('id').primaryKey(),owner:text('owner').notNull(),name:text('name').notNull(),width:integer('width').notNull(),height:integer('height').notNull(),hidden:integer('hidden').notNull().default(0),created:integer('created').notNull()},t=>[index('photos_visible_created').on(t.hidden,t.created)]);
export const messages=sqliteTable('messages',{id:text('id').primaryKey(),name:text('name').notNull(),body:text('body').notNull(),private:integer('private').notNull().default(0),hidden:integer('hidden').notNull().default(0),created:integer('created').notNull()},t=>[index('messages_visible_created').on(t.private,t.hidden,t.created)]);
export const limits=sqliteTable('limits',{key:text('key').primaryKey(),count:integer('count').notNull(),expires:integer('expires').notNull()});
