export const defaults = {date:'2026-10-02',venue:'',address:'',mapUrl:'',wifiName:'',wifiPassword:'',wifiSecurity:'WPA',playlistUrl:'',end:'2026-10-03T06:00',mode:'auto',photosOpen:true,messagesOpen:true,schedule:[{title:'DJ',at:'2026-10-02T20:00'},{title:'Pagode',at:'2026-10-02T23:00'},{title:'Playlist aberta',at:'2026-10-03T03:00'}]};
export type Config=typeof defaults;
export function stamp(v:string){return Date.parse(v+'-03:00')}
