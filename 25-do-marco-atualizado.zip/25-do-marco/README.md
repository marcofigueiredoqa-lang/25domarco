# 25 do Marco

Site mobile da festa, com identidade fornecida pelo organizador. React 19, Vinext e Cloudflare Worker; banco D1 e arquivos R2.

## Fluxos

- Início com arte central, envio de fotos, carrossel e programação.
- Álbum em duas colunas, foto inteira ao tocar, download individual e exclusão pelo remetente no mesmo navegador.
- Recados públicos no mural e privados acessíveis exclusivamente ao administrador.
- Programação em horário de Brasília, com atração atual destacada.
- Informações editáveis, mapa e QR Code Wi-Fi gerado no navegador, sem serviço externo.
- `/admin`: configuração, moderação e download de todas as fotos em um único ZIP transmitido em fluxo.

## Primeiro acesso administrativo

Entre no painel com a conta ChatGPT proprietária deste novo Site. O servidor compara a identidade encaminhada pela plataforma com `ADMIN_EMAIL`. Somente essa conta pode criar a senha inicial. Depois, use a senha; sessões HttpOnly expiram em oito horas. A senha é armazenada somente como hash PBKDF2-SHA256 com salt aleatório. `ADMIN_SESSION_SECRET` é um segredo do ambiente de produção.

A criação não copia as fotos, recados, senha ou banco do Site antigo. O novo Site começa privado. Configure o compartilhamento como público antes de distribuir o QR Code aos convidados. O painel continua protegido.

## Envios recuperáveis

A seleção é salva em IndexedDB no navegador, antes do envio. A fila é retomada ao abrir o site, quando a conexão volta e a cada 30 segundos enquanto a página está visível. Cada arquivo tem um ID persistente e a API é idempotente, evitando duplicação após resposta perdida. Um arquivo interrompido é reenviado inteiro; não há retomada por intervalo de bytes. Não funciona se o navegador apagar os dados locais ou não tiver espaço. A autoria depende de um cookie HttpOnly; limpar cookies remove a capacidade de excluir fotos antigas.

Fotos são processadas uma a uma para JPEG de até 2048 px e 800 KiB; miniaturas até 480 px e 60 KiB. HEIC tem fallback local. Originais e EXIF não são preservados. O ZIP contém as versões processadas, inclusive fotos ocultas.

## Desenvolvimento

Node 22.13+, pnpm. Execute `pnpm install --frozen-lockfile`, copie `.env.example` para `.env` com valores locais, gere o build e aplique `drizzle/0000_flowery_wraith.sql` ao D1 local. `pnpm dev` inicia a aplicação na configuração apropriada. Nunca copie segredos de produção para o código.

`node node_modules/typescript/bin/tsc --noEmit` verifica os tipos. `pnpm build` produz o Worker. O fluxo nativo de Sites aplica as migrações publicadas.

## Segurança

Todas as mutações validam Origin. Fotos têm formato e tamanho validados, IDs não sequenciais e autoria verificada no servidor. Fotos ocultas exigem sessão administrativa para acessar a mídia; o cache privado é revalidado e a autorização é conferida antes de qualquer resposta 304. Recados privados não são retornados por consultas públicas. Login e envios têm limites por IP/janela. Downloads do álbum exigem autorização a cada solicitação. A ação de apagar uma foto é permanente e exige confirmação na interface; ocultar é reversível.

O recurso opcional WebMCP oferece somente a leitura da programação e só registra quando o navegador o suporta.

## Atualização de envio e desempenho

Nome opcional para fotos (exibido como Convidado quando vazio). Recados continuam exigindo nome. O formulário permite selecionar arquivos ou abrir a câmera nos celulares compatíveis; no computador, o navegador pode abrir o seletor de arquivos. Miniaturas menores, carregamento sob demanda, decodificação assíncrona e revalidação por ETag evitam transferências repetidas sem liberar fotos ocultas. Imagens anteriores mantêm suas miniaturas existentes.
