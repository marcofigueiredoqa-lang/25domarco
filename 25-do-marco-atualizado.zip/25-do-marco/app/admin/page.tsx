import Party from '../party';
export const dynamic='force-dynamic';
export default function Admin(){return <Party adminPage/>}
