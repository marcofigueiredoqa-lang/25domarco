import Party from './party';
export default function Home(){return <Party/>}
