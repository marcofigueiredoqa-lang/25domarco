import type {Metadata} from 'next';
import './globals.css';
export const metadata:Metadata={title:'25 do Marco',description:'Fotos, recados e programação da festa do Marco.',icons:{icon:'/favicon.svg'}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="pt-BR"><body>{children}</body></html>}
